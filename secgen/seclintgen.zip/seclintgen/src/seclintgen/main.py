import click
# import datetime
# from seclintgen.utils import 
from utils import *
from dotenv import load_dotenv
import os

load_dotenv()
KEY = os.getenv("OPENAI_KEY")
MAX_ATTEMPTS = 3

output_file = f"{os.path.abspath(os.getcwd())}/report.txt"

AVAILABLE_MODELS = [
    "gemini-1.5-flash",
    "gpt-4o",
    "gpt-4o-2024-05-13",
    "gpt-4o-mini-2024-07-18" # for testing purposes; cheapest model
]

SECTIONS = {
    "Header" :  [("vuln-fix", "<vulnerability-name-here> in <file-name-here> (severity: <level-here>)")],
    "Summary":  [("what", "describe the vulnerability"),
                ("where", "locate the vulnerability (give me the line number or method name)"),
                ("why", "describe one possible consequence of not resolving this weakness"),
                ("how", "explain how an attacker would proceed to exploit this vulnerability")],
    "Program Analysis":    [("sources", "identify entry points in code where user input enters an application; do not explain them."),
                ("sinks", "identify all actions performed by the application, using user input from a source; do not explain them."),
                ("extra", "give additional information regarding the vulnerability.")],
    "Patch":    [("suggested-fix", "generate a code patch and explain how it resolves the vulnerability")],
    "Author":   [("author", "provide reporter name if available else None")],
    "Reference": [("method", "identify the methods used to generate the report, including generative AI if it was the case."),
                   ("reference", "provide the URL of the tools used.")]
}

TEMPLATE = """
vuln-detect: <weakness> in <file> (severity: <level-here>)


what: <describe the weakness/problem>
why:  <describe its impact>
how:  <describe how the weakness can be triggered (provide a simple example)>
when: <describe when the problem was found>
where: <describe where the problem is located <file:method:lines>>


unchecked-vars: <identified tainted variables not addressed by any control structure>
sources: <identifies all entry points in code where user input enters an application>
sinks: <identifies all actions performed by the application, using user input from a source>
extra: <additional information (to accomodate for different vulnerability types)>


suggested-fix: <code patch that fixes the vulnerability>


reported-by: reporter name <reporter-email@host.com>
co-reported-by: reporter name <reporter-email@host.com>

[For each tool used during the detection]
method: something that is not a tool here
reference: url if provided or None
"""

@click.command()
@click.option("--sample", required=True, help="Sample to be analyzed and explained")
@click.option("--context", required=False, help="Additional files for context purposes.")
@click.option("--model", default="gpt-4o-mini-2024-07-18", help="Name of the large language model that generates the reports [default: gemini-1.5-flash]")
@click.option("--key", default=KEY, help="API Key associated with the model")
@click.option("--template", help="Report template. [default: seclint interpretability standard]")
@click.option("--out", default=output_file, help="Output path. [default: report.txt]")
@click.option("--save", is_flag=True, default=False, help="If true, save output to a file.")
@click.option("--taint", is_flag=True, default=False, help="If true, taint analysis mode is ON. [default: true]")
@click.option("--verbose", is_flag=True, default=False, help="If true, verbose mode is ON. [default: false]")
def main(sample:str, context:str, model:str, key:str, template:str, save:bool, out:str, taint:bool, verbose:bool):
    # Setup model with api key
    assert model in AVAILABLE_MODELS
    assert len(key) > 1

    # Read sample and (optional) context files
    sample_code = read_file(sample) if sample else ""
    context_code = read_file(context) if context else ""
    assert len(sample_code) > 1

    # Setup template
    additional_instructions = {
            'template': SECTIONS,
    }

    instructions= [
            "You are a software security expert with experience in fill-in security reports \n",
            f"Consider the following vulnerable code snippet:  {sample_code} \n" ,
            f"Consider also the additional code context: {context_code} \n",
    ]

    model = load_model(model, key, instructions, MAX_ATTEMPTS)
    
    if taint is True:
        analyser = load_analyser("joern") # TODO: make it an argument later
        taint_report = analyser.analyse(files_to_analyse=[sample, context if context else None], verbose=verbose)
        if len(taint_report) > 0:
            additional_instructions['taint'] = taint_report
        # analyser.clean() 

    if model.generate_report(
            verbose=verbose,
            save_output=save,
            save_to=out,
            additional_instructions=additional_instructions
    ) == False:
        print(f"\t ❌ Aborting report generation! ❌")
        return 
    
    print(f"✅ 🧠 Security report was successfuly saved in {out}!")


if __name__ == '__main__':
    main()
    
    
