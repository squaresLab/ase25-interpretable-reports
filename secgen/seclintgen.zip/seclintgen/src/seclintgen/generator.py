import google.generativeai as genai
from abc import ABC, abstractmethod
import openai


class Generator(ABC):
    def __init__(self, instructions:list[str], api_key:str, model_name:str, max_attempts:int) -> None:
        self.instructions = instructions
        self.api_key = api_key
        self.model_name = model_name
        self.max_attempts = max_attempts
        self.retries = 0

    @abstractmethod
    def generate_report(self, verbose:bool, save_output:bool, save_to:str, additional_instructions:any = None) -> bool:
        pass


class OpenAIGenerator(Generator):
    def __init__(self, instructions:list[str], api_key:str, model_name:str, max_attempts:int) -> None:
        super().__init__(instructions, api_key, model_name, max_attempts)
        
        self.client = openai.OpenAI(
            api_key=api_key,
        )
        self.instructions : str = "".join(instructions)
        
        
    def generate_report(self, verbose: bool, save_output: bool, save_to: str, additional_instructions: any = None) -> bool:
        """Additional instructions contains the template sections."""
        assert additional_instructions['template'] is not None
        assert type(additional_instructions['template']) is dict

        template = additional_instructions['template']

        report:str = []
        header, summary, panalysis, patch, authors, reference = "", "", "", "", "", ""

        for section in template.keys():
            # process each section appropriately            
            match section:
                case 'Header':
                    header = self.process_header(template[section])
                # case 'Summary':
                #     summary = self.process_summary(template[section])
                # case 'Program Analysis':
                #     if 'taint' in additional_instructions.keys():
                #         panalysis = self.process_program_analysis(template[section], additional_instructions['taint'])
                # case 'Patch':
                #     patch = self.process_patch(template[section])
                # case 'Author':
                #     authors = self.process_author(template[section])
                # case 'Reference':
                #     if 'taint' in additional_instructions.keys():
                #         reference = self.process_reference(template[section], additional_instructions)
                #     else:
                #         reference = self.process_reference(template[section], "")
                case _:
                    continue
        
        report = f"{header} \n{summary} \n{panalysis} \n{patch} \n{authors} \n{reference}"

        if verbose:
            print(report)

        # Write each section to a file and save the report
        if save_output:
            try:
                with open(f"{save_to}", "w+") as f:
                    f.write(report)
                    return True
            except Exception as e:
                print(e)
                return False
    

    def process_header(self, section:list) -> str:
        header:str = ""

        for tag, explanation in section:
            completion = self.client.chat.completions.create(
                model="gpt-3.5-turbo-0125",
                messages=[
                    {"role": "system", "content": ""},
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "Hello!"}]
            )
            print(completion.choices[0].message)


            header += f"{tag}: {explanation}\n"
        return header



class GeminiGenerator(Generator):
    def __init__(self, instructions:list[str], api_key:str, model_name:str, max_attempts:int) -> None:
        """ Configures Gemini model to generate the reports."""
        super().__init__(instructions, api_key, model_name, max_attempts) 

        self.config = genai.configure(api_key=api_key)

        self.model : any = genai.GenerativeModel(
            model_name=model_name,
            system_instruction=instructions) 
        
        self.chat = self.model.start_chat()

        assert self.model is not None
        assert self.chat is not None


    def generate_report(self, verbose:bool, save_output:bool, save_to:str, additional_instructions:any = None) -> bool:
        """Additional instructions contains the template sections."""
        assert additional_instructions['template'] is not None
        assert type(additional_instructions['template']) is dict

        template = additional_instructions['template']

        report:str = []
        header, summary, panalysis, patch, authors, reference = "", "", "", "", "", ""

        for section in template.keys():
            # process each section appropriately
            match section:
                case 'Header':
                    header = self.process_header(template[section])
                case 'Summary':
                    summary = self.process_summary(template[section])
                case 'Program Analysis':
                    if 'taint' in additional_instructions.keys():
                        panalysis = self.process_program_analysis(template[section], additional_instructions['taint'])
                case 'Patch':
                    patch = self.process_patch(template[section])
                case 'Author':
                    authors = self.process_author(template[section])
                case 'Reference':
                    if 'taint' in additional_instructions.keys():
                        reference = self.process_reference(template[section], additional_instructions)
                    else:
                        reference = self.process_reference(template[section], "")
                case _:
                    continue
        
        report = f"{header} \n{summary} \n{panalysis} \n{patch} \n{authors} \n{reference}"

        if verbose:
            print(report)

        # Write each section to a file and save the report
        if save_output:
            try:
                with open(f"{save_to}", "w+") as f:
                    f.write(report)
                    return True
            except Exception as e:
                print(e)
                return False


    # TODO: refactor this!
    def process_header(self, section:list) -> str:
        """section is a tuple of (TAG, EXPLANATION)"""
        header:str = ""

        for tag, explanation in section:
            success = False
            while self.retries < self.max_attempts and not success:
                try:
                    response = self.chat.send_message(
                        f"Considering the code and context provided, fill-in the following sentence without highlighting the text: {explanation}"
                    )
                    header += f"{tag}: {response.text}"
                    success = True
                except Exception as e:
                    print(f"failed with {tag}")
                    self.retries += 1
    
        return header


    def process_summary(self, section:list) -> str:
        summary:str = ""

        for tag, explanation in section:
            self.retries = 0
            success = False

            while self.retries < self.max_attempts + 2 and not success:
                try:
                    response = self.chat.send_message(
                        f"Considering the code and context provided, {explanation} (output 2 sentences max)."
                    )
                    summary += f"{tag}: {response.text}" 
                    success = True
                except Exception as e:
                    print(f"failed with {tag}")
                    self.retries += 1

        return summary


    def process_program_analysis(self, section:list, additional_info:str) -> str:
        panalysis:str = ""

        if len(additional_info) > 1:
            # Give taint report
            self.chat.send_message(f"Besides the code and context provided, consider the following taint analysis report:\n {additional_info}.")
    
        # Generate text for each section
        for tag, explanation in section:
            self.retries = 0
            success = False

            while self.retries < self.max_attempts and not success:
                try:
                    response = self.chat.send_message(f"Considering the code and context provided, {explanation} (output 1 sentence)")

                    panalysis += f"{tag}: {response.text}" 
                    success = True
                except Exception as e:
                    print(f"failed with {tag}")
                    self.retries += 1

        return panalysis

    def process_patch(self, section:list) -> str:
        patch:str = ""

        for tag, explanation in section:
            self.retries = 0
            success = False
            while self.retries < self.max_attempts and not success:
                try:
                    response = self.chat.send_message(
                        f"Considering all the information you have, {explanation}"
                    )
                    patch += f"{tag}: {response.text}"
                    success = True
                except Exception as e:
                    print(f"failed with {tag}")
                    self.retries += 1
        return patch    


    def process_author(self, section:list) -> str:
        authors:str = ""

        for tag, explanation in section:
            self.retries = 0
            success = False

            while self.retries < self.max_attempts and not success:
                try:
                    response = self.chat.send_message(
                        f"Considering all the information you have, {explanation}"
                    )
                    authors += f"{tag}: {response.text}"
                    success = True
                except Exception as e:
                    self.retries += 1

        return authors


    def process_reference(self, section:list, additional_info:str) -> str:
        reference:str = ""

        for tag, explanation in section:
            if tag == "method":
                if "joern" in additional_info:
                    reference += f"{tag}: joern, generative AI (Gemini model)\n"
                else:
                    reference += f"{tag}: generative AI (Gemini model)\n"
            else:                
                if "joern" in additional_info:
                    reference += f"{tag}: https://joern.io/, https://gemini.google.com/\n"
                else:
                    reference += f"{tag}: https://gemini.google.com/\n"
        return reference