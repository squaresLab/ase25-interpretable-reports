import os
import re
from abc import ABC, abstractmethod

class Analyser(ABC):
    @abstractmethod
    def analyse(self, files_to_analyse: str | list[str], verbose:bool) -> str:
        pass

    @abstractmethod
    def clean(self):
        pass    

class JoernAnalyser(Analyser):

    def __init__(self) -> None:
        super().__init__()

    def analyse(self, files_to_analyse: str | list[str], verbose:bool) -> str:
        def cvss(cvss_score:str|float) -> str:
            severity_dict = {
                (0.0, 0.0): 'None',
                (0.1, 3.9): 'Low',
                (4.0, 6.9): 'Medium',
                (7.0, 8.9): 'High',
                (9.0, 10.0): 'Critical'
            }
            
            # Iterate through the dictionary to find the matching range
            for range_tuple, severity in severity_dict.items():
                if range_tuple[0] <= float(cvss_score) <= range_tuple[1]:
                    return severity
            return None
        
        def adjust_line(line:str) -> list:
            # line has the format: Result: 3.0 : Unchecked read/recv/malloc: sample.c:18:sample.c:<global>
            parts = line.split(':')
            severity = cvss(parts[1])
            weakness_type = parts[2]
            file = parts[3]
            line = parts[4]

            return f"severity: {severity} || weakness type: {weakness_type} || file: {file} || line: {line} || method: joern || reference: https://joern.io/"


        sample = files_to_analyse[0]
        context = files_to_analyse[1]

        # Process sample 
        output = os.popen(
            f"joern-scan {sample}"
        ).read()

        # parse and store the output
        pattern = r'^result: .*'
        
        # Find all matches in the log text
        matched_lines = re.findall(pattern, output, re.MULTILINE | re.IGNORECASE)
        result_lines = ""

        # print(matched_lines)
        for line in matched_lines:
            _l = adjust_line(line)
            result_lines += _l + "\n"
            
            if verbose:
                print(_l)

        return result_lines

        
    def clean(self):
        os.system(f"rm -rf ./workspace")

        