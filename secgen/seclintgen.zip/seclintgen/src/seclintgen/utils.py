from generator import Generator, GeminiGenerator, OpenAIGenerator
from analyser import Analyser, JoernAnalyser

def read_file(fpath:str) -> str: 
    """Read and parse report"""
    try:
        with open(fpath, 'r') as f:
            template = f.read()
            return template
    except Exception as exc:
        print (f"An error occurred while reading {fpath}: {exc}")
        return ""
    

def load_model(model_name:str, key:str, instructions:list[str], max_attempts:int) -> Generator:
    """Load a model"""

    match model_name:
        case "gemini-1.5-flash":
            return GeminiGenerator(instructions = instructions, 
                                    api_key = key, 
                                    model_name= model_name, 
                                    max_attempts= max_attempts) 
        case "gpt-4o-2024-05-13" | "gpt-4o":
            return OpenAIGenerator(instructions = instructions,
                                    api_key = key,
                                    model_name= model_name,
                                    max_attempts= max_attempts)
        case _:
            raise ValueError(f"Model {model_name} is not supported. Please provide a valid model.")



def load_analyser(command:str) -> Analyser:
    match command:
        case "joern":
            return JoernAnalyser()
        case "codeql":
            return CodeQLAnalyser()