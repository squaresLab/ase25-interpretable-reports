"""
seclintgen

A tool to generate security reports using LLMs and taint analysis.
"""

__version__ = "0.0.1"
__author__ = 'Claudia Mamede'
