from setuptools import find_packages, setup

with open('README.md', 'r') as f:
    long_description = f.read()

setup(
    name="seclintgen",
    version="0.0.1",
    author="Claudia Mamede",
    author_email="cmamede@andrew.cmu.edu",
    description="A short description of your project",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",
    url="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
    python_requires=">=3.6",
    install_requires=[
        "click",
        "google-generativeai"
    ],
    extras_require={
        "dev": ["pytest", "twine"]
    },
    package_data={},
    include_package_data=True,
    packages=find_packages("src"),
    package_dir={"": "src"},
    entry_points ={ 
                'console_scripts': [ 
                    'seclintgen = seclintgen.main:main'
                ] 
            }, 
)