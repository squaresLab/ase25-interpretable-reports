"""
seclint

A tool to measure compliance of security reports against our interpretability standard.
"""

__version__ = "0.0.1"
__author__ = 'Claudia Mamede'
__credits__ = 'Sofia Reis (github: @sofiaoreis)'